type Transport = {
  call: (payload: {
    tool: string;
    input: any;
  }) => Promise<any>;
};

export class GitHubMcpClient {
  private token: string;
  private transport: Transport;

  constructor(opts: {
    token: string;
    transport: Transport;
  }) {
    this.token = opts.token;
    this.transport = opts.transport;
  }

  async listReposWithBranches() {
    return this.transport.call({
      tool: "github.listReposWithBranches",
      input: {
        token: this.token,
      },
    });
  }

  async deleteBranches(input: {
    repo: string;
    branches: string[];
    dryRun: boolean;
  }) {
    return this.transport.call({
      tool: "github.deleteBranches",
      input: {
        token: this.token,
        ...input,
      },
    });
  }
}

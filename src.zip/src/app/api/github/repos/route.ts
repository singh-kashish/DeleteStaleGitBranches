import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { GitHubMcpClient } from "@/lib/mcp/github.client";
import { callMCP } from "@/lib/mcp/mcp.transport";

export async function GET() {
  const session = await getServerSession(authOptions);

  if (!session?.accessToken) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 }
    );
  }

  const client = new GitHubMcpClient({
    token: session.accessToken,
    transport: {
      call: callMCP,
    },
  });

  const data = await client.listReposWithBranches();
  return NextResponse.json(data);
}
